<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\Apply;

class ApplyController extends Controller
{
    /**
     * Show the form for editing the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $first_name = $request->input('first_name');
        $last_name = $request->input('last_name');
        $email = $request->input('email');
        $password = $request->input('password');
        $country_code = $request->input('country_code');
        $phone = $request->input('phone');
        $city = $request->input('city');
        $pin_code = $request->input('pin_code');
        $description = $request->input('description');
        $certificate = $request->input('certificate');
        $experience = $request->input('experience');

        $barber_cut = $request->input('barber_cut');
        $price1 = $request->input('price1');
        $stylish_cut = $request->input('stylish_cut');
        $price2 = $request->input('price2');
        $long_cut = $request->input('long_cut');
        $price3 = $request->input('price3');
        $beard_trim = $request->input('beard_trim');
        $price4 = $request->input('price4');
        $kids_cut = $request->input('kids_cut');
        $price5 = $request->input('price5');

        $apply = Apply::create([
            'first_name' => $first_name,
            'last_name' => $last_name,
            'email' => $email,
            'password' => $password,
            'country_code' => $country_code,
            'phone' => $phone,
            'city' => $city,
            'pin_code' => $pin_code,
            'description' => $description,
            'certificate' => $certificate,
            'experience' => $experience,
            'service_barber_cut_has' => ($barber_cut != null) ? 1 : 0,
            'service_barber_cut_price' => $price1,
            'service_stylish_cut_has' => ($stylish_cut != null) ? 1 :0,
            'service_stylish_cut_price' => $price2,
            'service_long_cut_has' => ($long_cut != null) ? 1 : 0,
            'service_long_cut_price' => $price3,
            'service_beard_trim_has' => ($beard_trim != null) ? 1 : 0,
            'service_beard_trim_price' => $price4,
            'service_kids_cut_has' => ($kids_cut != null) ? 1 : 0,
            'service_kids_cut_price' => $price5
        ]);

        $file = $request->file('client_photo');
        if ($file) {
            $filePath = 'uploads';
            $fileName = str_random(10) . '.' . $file->getClientOriginalExtension();
            $file->move($filePath, $fileName);
            $apply->client_photo = $filePath . '/' . $fileName;
            $apply->save();
        }

        //return redirect('/');
        return redirect('/')->with(
            'message',
            'Your request has been sent successfully. MyCut will contact you as soon as possible.'
        );
    }
}
